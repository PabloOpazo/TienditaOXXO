package tienditaoxxo;
import vistas.interfaz;

public class TienditaOXXO {
    
    public static void main(String[] args) {
        new interfaz().setVisible(true);
    }
    
}
