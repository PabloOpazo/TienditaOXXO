package tiendita_oxxo;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConexionBD {
    public static void main(String[] args) {
        Connection conexion = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            
            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/oxxo", "root", "");
            
            System.out.println("Conexion exitosa");
        } catch (Exception ex){
            System.out.println(ex.getMessage());
        }
    }    
}
